
package com.example.nightwinggame

interface GameTask {
 fun closeGame(score: Int)
}
